export const baseUrl='https://api.themoviedb.org/3';
export const API_KEY='9f86d799f6c9aef9a08a8014904bbed2';
export const imageUrl='https://image.tmdb.org/t/p/original';